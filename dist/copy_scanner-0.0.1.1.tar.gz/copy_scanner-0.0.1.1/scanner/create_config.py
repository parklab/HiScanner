import json
import os

def _check_file(fn):
    '''
    Checks if the file exists and is not empty. If not, return True.
    '''
    if not os.path.exists(fn):
        return True
    if os.stat(fn).st_size == 0:
        return True
    return False
def main():
    print("Initialization for Scanner's Single-Cell CNA Analysis Pipeline")
    print("-------------------------------------------------------------")
    print("You will be prompted to enter various file paths and parameters for the analysis.")
    print("If you prefer to use the default values, simply press Enter when prompted.")
    print("-------------------------------------------------------------")
    proceed = input("Do you wish to proceed with creating a JSON configuration file? (y/n): ").strip().lower()
    if proceed != "y":
        print("Operation cancelled. Exiting program.")
        exit()

    print("\nPlease enter the required information below:")

    data = {}
    fields = {
        "gatk_vcf": "Enter the path of the VCF containing raw GATK SNP calls: ",
        "phase_file": "Enter the path of the VCF containing phased germline SNPs: ",
        "bin_path": "Enter the path to the folder containing BIC-seq2 norm output: "
    }

    for field, prompt in fields.items():
        while True:
            data[field] = input(prompt)
            if not _check_file(data[field]):
                break
            print("File does not exist or is empty. Please re-enter.")

    data["germline"] = input("Enter the name of the bulk sample: ")
    data["singlecell"] = input("Enter the single cell names (if more than one cell, separate by commas: ")
    
    data["stem"] = input("Enter the path for the output folder: ")
    # create the stem directory if it doesn't exist
    os.makedirs(data["stem"], exist_ok=True)

    data["MAX_WGD"] = input("Enter the MAX_WGD value (integer, default 1): ")
    if data["MAX_WGD"] == '':
        data["MAX_WGD"] = 1
    data['LAMBDA'] = input("Enter the LAMBDA value (integer, default 100): ")
    if data['LAMBDA'] == '':
        data['LAMBDA'] = 100
    data['j'] = input("Enter the number of jobs to run in parallel (integer, default 8): ")
    if data['j'] == '':
        data['j'] = 8

    output_file = input("Enter the path where the output JSON file should be saved: ")
    while not output_file.endswith(".json"):
        print("Output file must be a JSON file. Please re-enter.")
        output_file = input("Enter the path where the output JSON file should be saved: ")

    while int(data["j"]) <= 0:
        print("Number of jobs must be a positive integer. Please re-enter.")
        data['j'] = input("Enter the number of jobs to run in parallel (integer, default 8): ")

    while int(data["MAX_WGD"]) <= 0:
        print("MAX_WGD must be a positive integer. Please re-enter.")
        data["MAX_WGD"] = input("Enter the MAX_WGD value (integer, default 1): ")

    while int(data["LAMBDA"]) <= 0:
        print("LAMBDA must be a positive integer. Please re-enter.")
        data['LAMBDA'] = input("Enter the LAMBDA value (integer, default 100): ")

    while not os.path.exists(data["stem"]):
        print("Output folder does not exist or cannot be created. Please re-enter.")
        data["stem"] = input("Enter the path for the output folder: ")

    with open(output_file, 'w') as outfile:
        json.dump(data, outfile, indent=4)

    print(f"Configuration data has been successfully written to {output_file}")

if __name__ == "__main__":
    main()
