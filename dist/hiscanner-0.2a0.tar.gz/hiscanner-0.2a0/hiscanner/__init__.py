from .version import __version__
from . import pp, tl, pl
# print(
#     f"""
#     **************************************************************************
#     * Welcome to scanner (v{__version__})!                                         *
#     * Scanner is a copy number caller for single cell DNA-seq data.          *
#     * For help and documentation, visit https://github.com/parklab/scanner   *
#     * Happy scanning!                                                        *
#     **************************************************************************
#     """
# )
